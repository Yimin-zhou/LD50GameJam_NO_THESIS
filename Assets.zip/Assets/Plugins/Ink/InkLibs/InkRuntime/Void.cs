﻿namespace Ink.Runtime
{
    public class Void : Runtime.Object
    {
        public Void ()
        {
        }
    }
}

